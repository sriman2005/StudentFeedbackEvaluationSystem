import React, { useEffect, useState } from 'react';
import AuthService from './AuthService';
import './Profile.css';

function Profile() {
    const [userProfile, setUserProfile] = useState(null);

    useEffect(() => {
        const userDetails = AuthService.getCurrentUser();
        setUserProfile(userDetails);
    }, []);

    return (
        <div className="profile-section">
            <h2>My Profile</h2>
            {userProfile ? (
                <div className="profile-details">
                    <div className="profile-item">
                        <strong>Username:</strong> {userProfile.username}
                    </div>
                    <div className="profile-item">
                        <strong>Email:</strong> {userProfile.email}
                    </div>
                    <div className="profile-item">
                        <strong>Phone Number:</strong> {userProfile.phoneNumber}
                    </div>
                    <div className="profile-item">
                        <strong>Role:</strong> {userProfile.role}
                    </div>
                </div>
            ) : (
                <p>Loading...</p>
            )}
        </div>
    );
}

export default Profile;
