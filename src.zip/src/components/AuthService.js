import axios from 'axios';

const API_URL = 'http://localhost:8080/api/auth/';

class AuthService {
    async login(username, password) {
        const response = await axios.post(`${API_URL}login`, { 
            username, 
            password 
        });
        if (response.data) {
            localStorage.setItem('user', JSON.stringify(response.data));
        }
        return response.data;
    }

    async signup(userData) {
        const response = await axios.post(`${API_URL}signup`, userData);
        return response.data;
    }

    logout() {
        localStorage.removeItem('user');
    }

    getCurrentUser() {
        return JSON.parse(localStorage.getItem('user'));
    }

    isAuthenticated() {
        return !!localStorage.getItem('user');
    }
}

const authServiceInstance = new AuthService();
export default authServiceInstance;
